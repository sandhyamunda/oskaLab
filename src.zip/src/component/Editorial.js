function Editorial(){
    return(
        <div className="editorial-container">
            <div className="editor">
                <h2>Editorial Board</h2>
                <h1>Editorial Board</h1>
                <p><b>Prof. Ajai Singh,</b>Department of Civil Engineering, Central University of Jharkhand,
                 Ranchi, India. Email: ajai.singh@cuj.ac.in, Phone +91 90314 50087</p>
                 <p></p>
                 <h1>Editors</h1>
                 <p></p>
                 <b>Dr. Ajay Pradhan,</b>President & CEO, Cetus Consulting Solution Services Pvt Ltd, New Delhi. Email:
                  ajay.pradhan@c2s2.in
            </div>
        </div>
    )
}
export default Editorial;