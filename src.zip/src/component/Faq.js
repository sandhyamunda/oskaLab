
function Faq(){
    return(
        <div className="faq-container"> 
            <div className="faq">
                <h1>FAQ?</h1>
            </div>
        </div>
    )
}
export default Faq;