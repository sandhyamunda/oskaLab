import { Box, Typography } from "@mui/material";
import { IoIosHelpCircleOutline } from "react-icons/io";

function Help(){
    return(
        <Box>
            <Typography>
                <IoIosHelpCircleOutline/>Help
            </Typography>
        </Box>
    )
}
export default Help;