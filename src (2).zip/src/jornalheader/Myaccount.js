import { Box, Typography } from "@mui/material";
import { RiAccountBoxLine } from "react-icons/ri";

function Myaccount(){
    return(
        <Box>
            <Typography></Typography>
          <RiAccountBoxLine/>  Myaccount
        </Box>
    )
}
export default Myaccount