import { Box, Typography } from "@mui/material";

function Journal(){
    return(
        <Box>
            <Typography>
                Journal
            </Typography>
        </Box>
    )
}
export default Journal;