import { Typography,Box } from "@mui/material";
import { IoSearch } from "react-icons/io5";

function Search(){
    return(
        <Box>
            <Typography>
              <IoSearch/>  Search
            </Typography>
        </Box>
    )
}
export default Search;