import { Box, Typography } from "@mui/material";
import { MdOutlineAccountBalance } from "react-icons/md";

function Signin(){
    return(
        <Box>
            <Typography>
               <MdOutlineAccountBalance/> Signin
            </Typography>
        </Box>
    )
}
export default Signin;