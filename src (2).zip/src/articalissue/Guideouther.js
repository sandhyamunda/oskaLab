import { Typography ,Box} from "@mui/material";

function Guide(){
    return(
        <Box sx={{borderRight: '1px solid #ccc', pr: 10}}>
        <Typography sx={{marginTop:2}}>
        Guide for outhers</Typography>
        </Box>
    )
}
export default Guide;