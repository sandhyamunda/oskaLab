function Aim(){
    return(
        <div className="ain-content">
            <div className="ain">
                <div>
                    <h2>Aim and Scope</h2>
                    <h3>Aim</h3>
                </div>
                <div>
                    <p>
                    Journal of Water Engineering and Management (online) is being published thrice a year i.e. 
                    in April, August, and December by Mrs P. Singh, Kaju Bagan, Hehal, Ranchi since April 2020.
                     It is an academic, open-access,
                     online, and peer-reviewed international journal. The aim of the journal is to:
                    </p>
                </div>
            </div>
        </div>
    )
}
export default Aim;