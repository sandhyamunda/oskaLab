import { Box, Typography } from "@mui/material";

function Mostpopular(){
    return(
        <Box>
            <Typography>
                Most popular
            </Typography>
        </Box>
    )
}