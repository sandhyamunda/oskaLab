import { Box, Typography } from "@mui/material";

function Topcited(){
    return(
        <Box>
            <Typography>
                Top cited
            </Typography>
        </Box>
    )
}
export default Topcited;