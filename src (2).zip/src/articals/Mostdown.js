import { Box, Typography } from "@mui/material";

function Mostdown(){
    return(
        <Box>
            <Typography>
                Most downloaded
            </Typography>
        </Box>
    )
}
export default Mostdown;