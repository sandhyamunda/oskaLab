import { Box, Typography } from "@mui/material";

function Latest(){
    return(
        <Box>
            <Typography>
                Latest published
            </Typography>
        </Box>
    )
}
export default Latest;