import { Box, Typography } from "@mui/material";

function ArticlesinPress(){
    return(
        <Box>
            <Typography>
                Articles in press
            </Typography>
        </Box>
    )
}
export default ArticlesinPress